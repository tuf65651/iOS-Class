//
//  main.swift
//  Lab03
//
//  Created by Shmuel Jacobs on 3/10/19.
//  Copyright © 2019 Shmuel Jacobs. All rights reserved.
//

import Foundation

let tbs = TempleBookstore();
tbs.main();
